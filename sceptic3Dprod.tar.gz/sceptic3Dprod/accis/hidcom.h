      integer ngrid
      parameter (ngrid=1025)
      real ytop(ngrid),ybot(ngrid)
      common/hideln/ytop,ybot
