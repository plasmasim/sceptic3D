c World and scale factors for 3-D.
      real xcbc2,ycbc2,scbx3,scby3,scbz3,fixedn
c; World units.
      real wx3min,wx3max,w3nx,wy3min,wy3max,w3ny,wz3min,wz3max,w3nz
      integer ihiding
      common/world3/xcbc2,ycbc2,scbx3,scby3,scbz3,
     $ wx3min,wx3max,w3nx,wy3min,wy3max,w3ny,wz3min,wz3max,w3nz,
     $	   fixedn,ihiding
