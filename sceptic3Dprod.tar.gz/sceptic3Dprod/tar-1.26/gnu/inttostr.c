/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define anytostr inttostr
#define inttype int
#include "anytostr.c"
