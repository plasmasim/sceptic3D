/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define anytostr uinttostr
#define inttype unsigned int
#include "anytostr.c"
